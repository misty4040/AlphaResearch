import { tavily } from "@tavily/core";
import { ChatGoogleGenerativeAI } from "@langchain/google-genai";
import { SystemMessage, HumanMessage } from "@langchain/core/messages";
import { AgentState } from "./state";
import { z } from "zod";

const getLLM = () => new ChatGoogleGenerativeAI({
  model: "gemini-2.5-flash",
  apiKey: process.env.GOOGLE_API_KEY || process.env.OPENAI_API_KEY,
  temperature: 0.2,
});

export async function generateQueriesNode(state: typeof AgentState.State) {
  const llm = getLLM();
  const { companyName } = state;
  const prompt = `You are a financial researcher. Generate 3 targeted search queries to research the company: ${companyName}. 
Focus on:
1. Recent news and general business model.
2. Recent financial performance or funding/valuation.
3. Competitors and market headwinds.
Respond with a JSON array of strings only.`;
  
  try {
    const response = await llm.invoke([{ role: "user", content: prompt }]);
    let content = typeof response.content === "string" ? response.content : (response.content?.[0] as any)?.text || "";
    content = content.replace(/```json/g, "").replace(/```/g, "");
    const queries = JSON.parse(content);
    return { queries, logs: [`Generated ${queries.length} search queries for ${companyName}.`] };
  } catch (e) {
    console.error("Error generating queries:", e);
    return { queries: [`${companyName} latest news`, `${companyName} financials`, `${companyName} competitors`], logs: ["Fallback queries generated."] };
  }
}

export async function searchNode(state: typeof AgentState.State) {
  const tvly = tavily();
  const { queries } = state;
  let allResults = [];
  
  for (const query of queries) {
    try {
      const response = await tvly.search(query, {
        searchDepth: "basic",
        maxResults: 3
      });
      allResults.push(...response.results);
    } catch (e) {
      console.error("Tavily search error:", e);
    }
  }
  return { searchResults: allResults, logs: [`Completed web searches and found ${allResults.length} relevant sources.`] };
}

export async function analysisNode(state: typeof AgentState.State) {
  const llm = getLLM();
  const { companyName, searchResults } = state;
  
  const searchContext = searchResults.map(r => `Title: ${r.title}\nContent: ${r.content}`).join("\n\n");
  
  const prompt = `You are a brilliant investment analyst. Analyze the following web search data for the company ${companyName}.
  
Provide a concise but detailed analysis covering:
- Executive Summary
- Business Model
- Financial Health / Momentum
- Competitive Landscape & Risks

Web Data:
${searchContext}`;
  
  try {
    const response = await llm.invoke([
      new SystemMessage("You are a professional investment analyst."),
      new HumanMessage(prompt)
    ]);
    let content = typeof response.content === "string" ? response.content : (response.content?.[0] as any)?.text || "";
    return { analysis: content, logs: ["Synthesized market data and generated financial analysis."] };
  } catch (e) {
    console.error("Error in analysis node:", e);
    return { analysis: "Failed to generate analysis.", logs: ["Error synthesizing market data."] };
  }
}

export async function decisionNode(state: typeof AgentState.State) {
  const llm = getLLM();
  const { companyName, analysis } = state;
  
  const prompt = `You are the Head of the Investment Committee. Based on the following analysis of ${companyName}, make a final investment decision.
  
You must decide whether to INVEST, PASS, or HOLD.

Provide your output as a JSON object with:
- verdict: "INVEST", "PASS", or "HOLD"
- report: A beautiful, final markdown report including the analysis and your final reasoning.

Analysis:
${analysis}`;
  
  try {
    const response = await llm.invoke([
      { role: "system", content: "You are the Head of the Investment Committee. Return ONLY a valid JSON object." },
      { role: "user", content: prompt }
    ]);
    let content = typeof response.content === "string" ? response.content : (response.content?.[0] as any)?.text || "";
    content = content.replace(/```json/g, "").replace(/```/g, "");
    const result = JSON.parse(content);
    return { verdict: result.verdict, report: result.report, logs: [`Investment Committee concluded with verdict: ${result.verdict}.`] };
  } catch (e) {
    console.error("Error in decision node:", e);
    return { verdict: "HOLD", report: "Error parsing committee decision. Defaulting to HOLD.", logs: ["Error in decision parsing."] };
  }
}
