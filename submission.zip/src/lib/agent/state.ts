import { Annotation } from "@langchain/langgraph";

export const AgentState = Annotation.Root({
  companyName: Annotation<string>(),
  queries: Annotation<string[]>(),
  searchResults: Annotation<any[]>(),
  analysis: Annotation<string>(),
  verdict: Annotation<string>(),
  report: Annotation<string>(),
  logs: Annotation<string[]>({
    reducer: (curr, next) => curr.concat(next),
    default: () => [],
  }),
});
