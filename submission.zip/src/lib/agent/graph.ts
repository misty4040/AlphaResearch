import { StateGraph, START, END } from "@langchain/langgraph";
import { AgentState } from "./state";
import { generateQueriesNode, searchNode, analysisNode, decisionNode } from "./nodes";

const workflow = new StateGraph(AgentState)
  .addNode("generate_queries", generateQueriesNode)
  .addNode("search", searchNode)
  .addNode("analyze", analysisNode)
  .addNode("decide", decisionNode)
  .addEdge(START, "generate_queries")
  .addEdge("generate_queries", "search")
  .addEdge("search", "analyze")
  .addEdge("analyze", "decide")
  .addEdge("decide", END);

export const appGraph = workflow.compile();
