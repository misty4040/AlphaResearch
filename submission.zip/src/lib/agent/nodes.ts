import { tavily } from "@tavily/core";
import { ChatOpenAI } from "@langchain/openai";
import { SystemMessage, HumanMessage } from "@langchain/core/messages";
import { AgentState } from "./state";
import { z } from "zod";

const getLLM = () => new ChatOpenAI({
  model: "gpt-4o-mini",
  temperature: 0.2,
});

export async function generateQueriesNode(state: typeof AgentState.State) {
  const llm = getLLM();
  const { companyName } = state;
  const prompt = `You are a financial researcher. Generate 3 targeted search queries to research the company: ${companyName}. 
Focus on:
1. Recent news and general business model.
2. Recent financial performance or funding/valuation.
3. Competitors and market headwinds.
Respond with a JSON array of strings only.`;
  
  const response = await llm.invoke([{ role: "user", content: prompt }]);
  
  try {
    let content = response.content as string;
    content = content.replace(/```json/g, "").replace(/```/g, "");
    const queries = JSON.parse(content);
    return { queries, logs: [`Generated ${queries.length} search queries for ${companyName}.`] };
  } catch (e) {
    return { queries: [`${companyName} latest news`, `${companyName} financials`, `${companyName} competitors`], logs: ["Fallback queries generated."] };
  }
}

export async function searchNode(state: typeof AgentState.State) {
  const tvly = tavily();
  const { queries } = state;
  let allResults = [];
  
  for (const query of queries) {
    try {
      const response = await tvly.search(query, {
        searchDepth: "basic",
        maxResults: 3
      });
      allResults.push(...response.results);
    } catch (e) {
      console.error("Tavily search error:", e);
    }
  }
  return { searchResults: allResults, logs: [`Completed web searches and found ${allResults.length} relevant sources.`] };
}

export async function analysisNode(state: typeof AgentState.State) {
  const llm = getLLM();
  const { companyName, searchResults } = state;
  
  const searchContext = searchResults.map(r => `Title: ${r.title}\nContent: ${r.content}`).join("\n\n");
  
  const prompt = `You are a brilliant investment analyst. Analyze the following web search data for the company ${companyName}.
  
Provide a concise but detailed analysis covering:
- Executive Summary
- Business Model
- Financial Health / Momentum
- Competitive Landscape & Risks

Web Data:
${searchContext}`;
  
  const response = await llm.invoke([
    new SystemMessage("You are a professional investment analyst."),
    new HumanMessage(prompt)
  ]);
  
  return { analysis: response.content as string, logs: ["Synthesized market data and generated financial analysis."] };
}

export async function decisionNode(state: typeof AgentState.State) {
  const llm = getLLM();
  const { companyName, analysis } = state;
  
  const prompt = `You are the Head of the Investment Committee. Based on the following analysis of ${companyName}, make a final investment decision.
  
You must decide whether to INVEST, PASS, or HOLD.

Provide your output as a JSON object with:
- verdict: "INVEST", "PASS", or "HOLD"
- report: A beautiful, final markdown report including the analysis and your final reasoning.

Analysis:
${analysis}`;
  
  const response = await llm.invoke([
    { role: "system", content: "You are the Head of the Investment Committee. Return ONLY a valid JSON object." },
    { role: "user", content: prompt }
  ]);
  
  try {
    let content = response.content as string;
    content = content.replace(/```json/g, "").replace(/```/g, "");
    const result = JSON.parse(content);
    return { verdict: result.verdict, report: result.report, logs: [`Investment Committee concluded with verdict: ${result.verdict}.`] };
  } catch (e) {
    return { verdict: "HOLD", report: "Error parsing committee decision. Defaulting to HOLD.", logs: ["Error in decision parsing."] };
  }
}
