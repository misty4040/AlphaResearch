"use client";

import { useState } from "react";

export default function Home() {
  const [companyName, setCompanyName] = useState("");
  const [loading, setLoading] = useState(false);
  const [logs, setLogs] = useState<{ node: string; message: string }[]>([]);
  const [result, setResult] = useState<{ verdict: string; report: string } | null>(null);
  const [error, setError] = useState("");

  const startResearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyName) return;

    setLoading(true);
    setLogs([]);
    setResult(null);
    setError("");

    try {
      const res = await fetch("/api/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyName }),
      });

      if (!res.ok) {
        throw new Error("Failed to start research");
      }

      const reader = res.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      
      let done = false;
      while (reader && !done) {
        const { value, done: readerDone } = await reader.read();
        done = readerDone;
        if (value) {
          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split("\n");
          for (const line of lines) {
            if (line.startsWith("data: ")) {
              const dataStr = line.replace("data: ", "").trim();
              if (dataStr) {
                try {
                  const data = JSON.parse(dataStr);
                  if (data.type === "log") {
                    setLogs((prev) => [...prev, { node: data.node, message: data.message }]);
                  } else if (data.type === "result") {
                    setResult({ verdict: data.verdict, report: data.report });
                  } else if (data.type === "error") {
                    setError(data.message);
                  }
                } catch (err) {}
              }
            }
          }
        }
      }
    } catch (err: any) {
      setError(err.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 text-white p-8 font-sans selection:bg-indigo-500/30">
      <div className="max-w-4xl mx-auto space-y-12">
        
        {/* Header */}
        <div className="text-center space-y-4 pt-12">
          <div className="inline-block rounded-full px-3 py-1 text-xs font-medium bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mb-4">
            AI-Powered Investment Analysis
          </div>
          <h1 className="text-5xl font-bold tracking-tight bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
            AlphaResearch
          </h1>
          <p className="text-slate-400 max-w-xl mx-auto text-lg">
            Enter a company name and our AI agent will perform deep web research, financial analysis, and provide an investment verdict.
          </p>
        </div>

        {/* Input Form */}
        <form onSubmit={startResearch} className="relative max-w-2xl mx-auto group">
          <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative flex items-center bg-slate-900 border border-slate-800 rounded-2xl p-2 shadow-2xl backdrop-blur-xl">
            <div className="pl-4 pr-2 text-slate-500">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input 
              type="text" 
              placeholder="e.g. NVIDIA, Tesla, or a stealth startup..."
              className="flex-1 bg-transparent border-none outline-none text-lg px-2 py-3 placeholder-slate-600 focus:ring-0"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              disabled={loading}
            />
            <button 
              type="submit" 
              disabled={loading || !companyName}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_0_15px_rgba(79,70,229,0.3)]"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Researching...
                </span>
              ) : "Research"}
            </button>
          </div>
        </form>

        {error && (
          <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl max-w-2xl mx-auto text-center">
            {error}
          </div>
        )}

        {/* Live Progress Logs */}
        {logs.length > 0 && !result && (
          <div className="max-w-2xl mx-auto bg-slate-900/50 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
            <h3 className="text-sm font-semibold text-slate-400 mb-4 uppercase tracking-wider flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
              </span>
              Agent Live Progress
            </h3>
            <div className="space-y-3 font-mono text-sm">
              {logs.map((log, i) => (
                <div key={i} className="flex gap-4 items-start text-slate-300 animate-in fade-in slide-in-from-bottom-2 duration-300">
                  <span className="text-slate-600 mt-0.5">[{log.node}]</span>
                  <span className="text-indigo-200">{log.message}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Final Report */}
        {result && (
          <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
              
              <div className="p-8 border-b border-slate-800 bg-slate-900/80 backdrop-blur-xl flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <p className="text-slate-400 text-sm font-medium mb-1 uppercase tracking-widest">Investment Verdict</p>
                  <h2 className="text-3xl font-bold">{companyName}</h2>
                </div>
                <div className={`px-8 py-4 rounded-2xl font-bold text-2xl tracking-wide shadow-lg border
                  ${result.verdict === 'INVEST' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 shadow-emerald-500/10' : 
                    result.verdict === 'PASS' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20 shadow-rose-500/10' : 
                    'bg-amber-500/10 text-amber-400 border-amber-500/20 shadow-amber-500/10'}`}>
                  {result.verdict}
                </div>
              </div>

              <div className="p-8 prose prose-invert max-w-none prose-headings:text-indigo-300 prose-a:text-indigo-400 hover:prose-a:text-indigo-300 prose-hr:border-slate-800 text-slate-300 leading-relaxed">
                <div dangerouslySetInnerHTML={{ __html: formatMarkdown(result.report) }} />
              </div>

            </div>
          </div>
        )}

      </div>
    </main>
  );
}

function formatMarkdown(text: string) {
  let html = text
    .replace(/^### (.*$)/gim, '<h3 class="text-xl font-semibold mt-6 mb-3 text-white">$1</h3>')
    .replace(/^## (.*$)/gim, '<h2 class="text-2xl font-bold mt-8 mb-4 border-b border-slate-800 pb-2 text-white">$1</h2>')
    .replace(/^# (.*$)/gim, '<h1 class="text-3xl font-bold mt-10 mb-6 text-white">$1</h1>')
    .replace(/\*\*(.*)\*\*/gim, '<strong class="text-white">$1</strong>')
    .replace(/\*(.*)\*/gim, '<em>$1</em>')
    .replace(/\n\n/g, '</p><p class="mb-4">')
    .replace(/\n/g, '<br />');
    
  html = html.replace(/- (.*$)/gim, '<li class="ml-4 list-disc mb-1">$1</li>');
  
  return `<p class="mb-4">${html}</p>`;
}
