# AlphaResearch: AI Investment Research Agent

## Overview
AlphaResearch is a full-stack, AI-powered investment research agent. Given a company name, it dynamically searches the web for recent news, financial performance, and competitive headwinds. It synthesizes this information using a LangGraph-powered AI agent, then renders a final investment verdict (INVEST, PASS, or HOLD) along with a beautifully formatted report.

## How to run it
1. Install dependencies:
   ```bash
   npm install
   ```
2. Create a `.env.local` file in the root directory and add your API keys:
   ```env
   OPENAI_API_KEY="your-openai-api-key"
   TAVILY_API_KEY="your-tavily-api-key"
   ```
3. Run the development server:
   ```bash
   npm run dev
   ```
4. Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## How it works
- **Frontend**: A Next.js 15 App Router React application styled with Tailwind CSS (v4). It features a dark-mode, glassmorphic UI. When a user submits a company name, it opens a Server-Sent Events (SSE) connection to the backend.
- **Backend / Agent**: Powered by Next.js API routes and `LangGraph`. The agent's workflow consists of four nodes:
  1. `Query Generator`: Creates 3 targeted search queries for the company (News, Financials, Competitors) using OpenAI.
  2. `Search Node`: Uses the Tavily API to fetch real-time search results for the queries.
  3. `Analysis Node`: Synthesizes the web data into a coherent business and financial analysis.
  4. `Decision Node`: Evaluates the analysis and makes the final INVEST/PASS/HOLD decision, generating a markdown report.

## Key decisions & trade-offs
- **Streaming over SSE vs WebSockets**: I chose Server-Sent Events (SSE) from the Next.js API route because it integrates natively with Next.js edge/serverless functions without requiring a separate stateful WebSocket server. This makes Vercel deployment seamless.
- **Tavily over direct Scraping**: I chose the Tavily Search API because it is purpose-built for LLMs and returns clean, extracted text from pages, saving significant token overhead and avoiding complex Cheerio/Puppeteer scraping setups.
- **LangGraph over simple Chains**: I chose LangGraph to structure the agent. While a simple LangChain pipeline could have worked, LangGraph allows for clear state transitions, easy streaming of intermediate steps (node-by-node updates to the UI), and makes it trivial to add complex routing or human-in-the-loop features later.
- **Tailwind CSS**: The initial plan was to use Vanilla CSS to abide by specific system guidelines, but I pivoted to Tailwind CSS as per explicit user request. It allows for highly maintainable, utility-first styling which made creating the glassmorphic animations rapid.

## Example runs
- **NVIDIA**: Agent successfully recognized its dominant market share in AI accelerators (GPUs) and strong financial growth, concluding with an **INVEST** verdict.
- **Peloton**: Agent recognized its declining hardware sales and pivot attempts, noting high risks and concluding with a **PASS** or **HOLD** depending on the risk appetite in the generated report.

## What you would improve with more time
- **Advanced Tools**: Add nodes to pull structured financial data directly from APIs like AlphaVantage or Yahoo Finance for deeper quantitative analysis.
- **Human-in-the-Loop**: Pause the graph after the `Analysis Node` to let the user review the findings and ask clarifying questions before the Investment Committee makes a final decision.
- **Markdown Rendering**: Use `react-markdown` and `rehype` plugins in the frontend for safer and more feature-rich rendering of the AI's report.
- **Error Handling & Retries**: Add robust retry policies within LangGraph to handle transient search or LLM API failures gracefully.
